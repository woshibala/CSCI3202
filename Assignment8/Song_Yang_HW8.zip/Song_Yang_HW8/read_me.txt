This is part 1 for Assignment8
Enter "python HMM.py" in command line.
The result is three probability
1.emission probability
2 transition probability
3. initial probability

The result will be print in the console and three .txt file
"emissonprbability.txt"
"transitionalprobabiliry.txt"
"initialprobability.txt"

